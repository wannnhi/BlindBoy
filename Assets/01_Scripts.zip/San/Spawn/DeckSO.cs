using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Deck", menuName = "SO/Deck")]
public class DeckSO : ScriptableObject
{
    public List<EntityStatusSO> agentDeckList = new List<EntityStatusSO>();

    private const string SaveFileName = "DeckData.json";

    public void InitDeck()
    {
        agentDeckList.Clear();
    }

    public void SaveDeck()
    {
        DeckData data = new DeckData();

        foreach (var agent in agentDeckList)
        {
            data.agentNames.Add(agent.name); // �ʿ��� ������ �߰�
        }

        SaveManager.Save(SaveFileName, data);
    }

    public void LoadDeck()
    {
        DeckData data = SaveManager.Load<DeckData>(SaveFileName);

        // ���� �����͸� �ʱ�ȭ�ϰ� �� ������ �߰�
        agentDeckList.Clear();

        foreach (var agentName in data.agentNames)
        {
            // �̸����� EnityStatusSO�� ã�Ƽ� ����Ʈ�� �߰�
            EntityStatusSO foundAgent = Resources.Load<EntityStatusSO>($"Path/To/Agents/{agentName}");
            if (foundAgent != null)
            {
                agentDeckList.Add(foundAgent);
            }
            else
            {
                Debug.LogWarning($"Agent '{agentName}' not found in Resources.");
            }
        }
    }
}



[System.Serializable]
public class DeckData
{
    public List<string> agentNames = new List<string>();
}
