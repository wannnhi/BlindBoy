using UnityEngine;

public interface IAfterInitable
{
    public void AfterInit();
}
